var gamejs = require('gamejs');
var box2d = require('./Box2dWeb-2.1.a.3');
var vectors = require('gamejs/utils/vectors');
var math = require('gamejs/utils/math');

var SCALE=15; 
var CANVAS_WIDTH=600;   //screen width in pixels
var CANVAS_HEIGHT=400;
console.log("HI")

//initialize display
var display = gamejs.display.setMode([CANVAS_WIDTH, CANVAS_HEIGHT]);
var b2world;

//SET UP B2WORLD
b2world = new box2d.b2World(
    new box2d.b2Vec2(0, 10), true
    );

var fixDef = new box2d.b2FixtureDef;
fixDef.density = 1.0;
fixDef.friction = 0.5;
fixDef.restitution = 0.2;

var bodyDef = new box2d.b2BodyDef;
bodyDef.type = box2d.b2Body.b2_staticBody;
       
// positions the center of the object (not upper left!)
bodyDef.position.x = CANVAS_WIDTH / 2 / SCALE;
bodyDef.position.y = CANVAS_HEIGHT / SCALE;

fixDef.shape = new box2d.b2PolygonShape;
       
// half width, half height.
fixDef.shape.SetAsBox((300 / SCALE) / 2, (10/SCALE) / 2);

b2world.CreateBody(bodyDef).CreateFixture(fixDef);
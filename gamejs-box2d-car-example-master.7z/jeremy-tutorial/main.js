// var box2d = require('box2d');
// Define the canvas
var canvaselem = document.getElementById("canvas");
var context = canvaselem.getContext("2d");
var canvaswidth = canvaselem.width-0;
var canvasheight = canvaselem.height-0;

// Define the world
var gravity = new Box2D.b2Vec2(0, -10);
var doSleep = true;
var world = new Box2D.b2World(gravity, doSleep);

var deletionBuffer = 4;

function init(){
    console.log('hi');
}